# Política de Privacidad

Gracias por confiar en Asistime.ai. Esta Política de Privacidad describe cómo recopilamos, usamos y protegemos tu información personal cuando usás nuestra plataforma. Tu privacidad es importante para nosotros y nos comprometemos a manejar tus datos de manera responsable y transparente.

## Información que recopilamos

- **Datos de contacto**: nombre, correo electrónico, número de teléfono.
- **Datos de uso**: información sobre cómo usás nuestra plataforma.
- **Datos técnicos**: dirección IP, tipo de navegador, sistema operativo.

## Cómo usamos tu información

Usamos tu información para:

- Proveer y mejorar nuestros servicios.
- Comunicarnos con vos.
- Personalizar tu experiencia en la plataforma.
- Cumplir con obligaciones legales.

## Compartir tu información

No vendemos tu información personal. Podemos compartirla con:

- Proveedores de servicios que nos ayudan a operar la plataforma.
- Autoridades legales si lo exige la ley.

## Tus derechos

Tenés derecho a acceder, corregir o eliminar tu información personal. Para ejercer estos derechos, escribinos a privacidad@asistime.ai.

## Seguridad

Tomamos medidas para proteger tu información, pero ningún sistema es completamente seguro.

## Cambios a esta política

Podemos actualizar esta Política. Te notificaremos si hay cambios importantes.

## Contacto

Si tenés dudas, escribinos a privacidad@asistime.ai.
