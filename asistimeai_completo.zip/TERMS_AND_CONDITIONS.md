# Términos y Condiciones

Bienvenido a Asistime.ai. Al usar nuestra plataforma, aceptás estos términos y condiciones. Te pedimos que los leas atentamente antes de utilizar nuestros servicios.

## 1. Uso de la plataforma

La plataforma está destinada a ayudar a automatizar tareas mediante inteligencia artificial. Te comprometés a usarla de forma legal y ética.

## 2. Cuenta de usuario

Podés necesitar una cuenta para acceder a ciertas funciones. Sos responsable de mantener la confidencialidad de tu cuenta.

## 3. Propiedad intelectual

Todo el contenido y código son propiedad de Asistime.ai o de sus licenciantes. No podés copiar, modificar ni distribuir nuestro contenido sin permiso.

## 4. Limitación de responsabilidad

Asistime.ai no garantiza que la plataforma funcione sin errores o interrupciones. No somos responsables por daños derivados del uso del servicio.

## 5. Cambios a los términos

Podemos modificar estos términos en cualquier momento. Si continuás usando la plataforma después de los cambios, se considera que los aceptás.

## 6. Contacto

Para consultas sobre estos términos, escribinos a legal@asistime.ai.
