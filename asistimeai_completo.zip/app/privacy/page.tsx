import fs from 'fs'
import path from 'path'
import Markdown from 'react-markdown'

export default function PrivacyPage() {
  const filePath = path.join(process.cwd(), 'PRIVACY_POLICY.md')
  const content = fs.readFileSync(filePath, 'utf8')

  return (
    <div className="max-w-3xl mx-auto p-10 prose">
      <h1>Política de Privacidad</h1>
      <Markdown>{content}</Markdown>
    </div>
  )
}
