import fs from 'fs'
import path from 'path'
import Markdown from 'react-markdown'

export default function TermsPage() {
  const filePath = path.join(process.cwd(), 'TERMS_AND_CONDITIONS.md')
  const content = fs.readFileSync(filePath, 'utf8')

  return (
    <div className="max-w-3xl mx-auto p-10 prose">
      <h1>Términos y Condiciones</h1>
      <Markdown>{content}</Markdown>
    </div>
  )
}
